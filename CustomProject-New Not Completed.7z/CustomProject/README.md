# angular-custom-project

Angular 7 Custom Project with Angular CLI
