﻿import { Injectable } from "@angular/core";

@Injectable({ providedIn: "root" })
export class UserService {
  public data: any = {
    header: {
      currentDate: new Date(),
      // logonTime: `${new Date().getHours} - ${new Date().getMinutes()} - ${new Date().getSeconds()}`,
      cssID: "CAQ",
      dvop: "",
      accounts: "",
      amtPromised: ""
    },

    customersData: [
      {
        customerType: "Primary Account",
        customerName: "JIABAO WEN",
        totalAcc: 3,
        totalBalance: 18000,
        creditAvailable: 20000,
        acct: "1234-5678-9810-1234",
        ssn: "XXX.XXX.6703",
        mmn: "XXX-XXXX-XXXX",
        address: {
          line1: "EDGEMOOR",
          line2: "",
          city: "",
          state: "DE",
          postalCode: "19802",
          countryCode: ""
        },
        email: "harryPotter@hogwart.com",
        h: "(201)-645-2871",
        w: "(201)-645-2871",
        ao: "(201)-645-2871",
        cardsData: [
          {
            cardNo: "1234",
            amtDue: 10.0,
            amtPstDue: 0.0,
            dayPstDue: 0,
            balance: 39.0,
            creditLimit: 20000.0,
            availCredit: 19961.0,
            lastPayment: 0.0,
            lastMonetory: "Credit",
            ctdActivity: "Active",
            disputes: "",
            transAmt: 'Y',
            timesOverLimited: 2,
            intSavings: 5000
          },
          {
            cardNo: "5678",
            amtDue: 10.0,
            amtPstDue: 0.0,
            dayPstDue: 0,
            balance: 39.0,
            creditLimit: 20000.0,
            availCredit: 19961.0,
            lastPayment: 0.0,
            lastMonetory: "Credit",
            ctdActivity: "Active",
            disputes: "",
            transAmt: 'Y',
            timesOverLimited: 4,
            intSavings: 77000
          },
          {
            cardNo: "9876",
            amtDue: 20.0,
            amtPstDue: 0.0,
            dayPstDue: 0,
            balance: 59.0,
            creditLimit: 26000.0,
            availCredit: 19061.0,
            lastPayment: 0.0,
            lastMonetory: "Credit",
            ctdActivity: "Active",
            disputes: "",
            transAmt: 'Y',
            timesOverLimited: 12,
            intSavings: 504400
          }
        ]
      },
      {
        customerType: "Secondary Account",
        customerName: "RICHARD WEN",
        totalAcc: 1,
        totalBalance: 8000,
        creditAvailable: 2000,
        acct: "3456-7890-1234-5678",
        ssn: "XXX.XXX.6903",
        mmn: "XXX-XXXX-XXXX",
        address: {
          line1: "EDGEMOOR",
          line2: "",
          city: "",
          state: "DE",
          postalCode: "19802",
          countryCode: ""
        },
        email: "chinese@gov.ch",
        h: "(301)-645-2871",
        w: "(301)-645-2871",
        ao: "(301)-645-2871",
        cardsData: [
          {
            cardNo: "1236",
            amtDue: 130.0,
            amtPstDue: 30.0,
            dayPstDue: 0,
            balance: 3933.0,
            creditLimit: 2330000.0,
            availCredit: 1339961.0,
            lastPayment: 0.0,
            lastMonetory: "Credit",
            ctdActivity: "Active",
            disputes: "",
            transAmt: 'Y',
            timesOverLimited: 2,
            intSavings: 25000
          }
        ]
      },
      {
        customerType: "Auth Account",
        customerName: "MARY WEN",
        totalAcc: 2,
        totalBalance: 48000,
        creditAvailable: 70000,
        acct: "9876-5432-1098-7654",
        ssn: "XXX.XXX.6704",
        mmn: "XXX-XXXX-XXXX",
        address: {
          line1: "EDGEMOOR",
          line2: "",
          city: "",
          state: "DE",
          postalCode: "19802",
          countryCode: ""
        },
        email: "tonyStark@marvels.com",
        h: "(201)-665-2871",
        w: "(201)-665-2871",
        ao: "(201)-665-2871",
        cardsData: [
          {
            cardNo: "1239",
            amtDue: 1330.0,
            amtPstDue: 0.0,
            dayPstDue: 0,
            balance: 3933.0,
            creditLimit: 3320000.0,
            availCredit: 1119961.0,
            lastPayment: 110.0,
            lastMonetory: "Credit",
            ctdActivity: "Active",
            disputes: "",transAmt: 'Y',
            timesOverLimited: 42,
            intSavings: 65000
          },
          {
            cardNo: "5678",
            amtDue: 90.0,
            amtPstDue: 0.0,
            dayPstDue: 0,
            balance: 439.0,
            creditLimit: 2000000.0,
            availCredit: 33333.0,
            lastPayment: 0.0,
            lastMonetory: "Debit",
            ctdActivity: "InActive",
            disputes: "",
            transAmt: 'Y',
            timesOverLimited: 22,
            intSavings: 533000
          }
        ]
      }
    ]
  };
  constructor() {}


}
