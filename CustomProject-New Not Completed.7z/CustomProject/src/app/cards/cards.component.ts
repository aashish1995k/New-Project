import { Component, OnInit, Input } from "@angular/core";
import { NgbDateStruct, NgbCalendar } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "layout-cards",
  templateUrl: "./cards.component.html",
  styleUrls: ["./cards.component.css"]
})
export class CardsComponent implements OnInit {
  @Input() cardDataList: any;
  selectedCard: number = 0;
  selectedTab: number = 1;
  tabList: any[] = [{label: 'To Be Discussed', icon:'fas fa-file-alt'}, {label: 'Account Summary', icon:'fas fa-id-card'}, {label: 'To Be Discussed', icon:'fas fa-file-invoice-dollar'}, {label: 'To Be Discussed', icon:'fas fa-hotel'}];
  model: NgbDateStruct;
  calendarVisibility: boolean = true;
  constructor(calendar: NgbCalendar) {
    this.model = calendar.getToday();
  }

  ngOnInit() {
    console.log(this.cardDataList);
  }

  // Syncs the Card tab's and Data shows on click
  syncCardData(index) {
    console.log("called", index);
    this.selectedCard = +index;
    console.log(this.selectedCard);
  }

  // Syncs the tab's on click
  syncTabView(index) {    
    this.selectedTab = +index;   
  }

  // toggles the visiblity of calendar
  toggleCalendar() {
    this.calendarVisibility = !this.calendarVisibility;
  }
}
