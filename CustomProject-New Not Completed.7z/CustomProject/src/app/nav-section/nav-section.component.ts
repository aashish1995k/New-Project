import { Component, OnInit } from '@angular/core';
import { UserService } from '@app/_services';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'layout-nav',
  templateUrl: './nav-section.component.html',
  styleUrls: ['./nav-section.component.css']
})
export class NavSectionComponent implements OnInit {
  customersData: any;
  currentSelectedCustomer: any;
  defaultCustomer: string = 'Primary Customer';
  customerDataForm: FormGroup;
  showMMN: boolean = false;
  buttonName: string = 'Show';
  cardDataList: any;
  constructor(private formBuilder: FormBuilder, private userService: UserService) { }

  ngOnInit() {
    this.customersData = this.userService.data.customersData;
    this.initializeCustomerSection(this.defaultCustomer);
    this.initializeCustomerData();   
  }

  initializeCustomerData() {   
    this.customerDataForm = this.formBuilder.group({
      customerType: [this.currentSelectedCustomer[0].customerType, Validators.required],
      account: [this.currentSelectedCustomer[0].acct, Validators.required],
      ssn: [this.currentSelectedCustomer[0].ssn],
      mmn: [this.currentSelectedCustomer[0].mmn],
      line1: [this.currentSelectedCustomer[0].address.line1],
      line2: [`${this.currentSelectedCustomer[0].address.state}, ${this.currentSelectedCustomer[0].address.postalCode}`],
      email: [this.currentSelectedCustomer[0].email],
      h: [this.currentSelectedCustomer[0].h],
      w: [this.currentSelectedCustomer[0].w],
      ao: [this.currentSelectedCustomer[0].ao]
    });  
    this.cardDataList = this.currentSelectedCustomer[0].cardsData;    
  }

  initializeCustomerSection(customerType:string) {
    this.currentSelectedCustomer = this.customersData.filter(customer => {
      return customer.customerType === customerType;
    })
  }
  
  onCustomerChange(customer:any) {   
    this.initializeCustomerSection(customer.customerType);
    this.initializeCustomerData();   
  }

  _showMMN() {
    this.showMMN = !this.showMMN;
    if(this.showMMN)  
      this.buttonName = "Hide";
    else
      this.buttonName = "Show";
  }
}
