import { Component, OnInit, Input } from "@angular/core";
import { NgbDateStruct, NgbCalendar } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from "@app/_services";
@Component({
  selector: 'app-section2',
  templateUrl: './section2.component.html',
  styleUrls: ['./section2.component.css']
})
export class Section2Component implements OnInit {
  cardDataList: any;
  customersData: any;
  @Input() defaultCustomer: string;
  
  selectedCard: number = 0;
  selectedTab: number = 0;
  tabList: any[] = [{label: 'Account Summary', icon:'fas fa-file-alt'}, {label: 'Account Details', icon:'fas fa-id-card'}, {label: 'Account Info', icon:'fas fa-file-invoice-dollar'}, {label: 'To Be Discussed', icon:'fas fa-hotel'}];
  model: NgbDateStruct;
  calendarVisibility: boolean = true;
  currentSelectedCustomer: any;
  customerDataForm: FormGroup;
  showMMN: boolean = false;
  buttonName: string = 'Show';

  constructor(calendar: NgbCalendar,private formBuilder: FormBuilder, private userService: UserService) {
    this.model = calendar.getToday();
  }

  ngOnInit() {
    this.customersData = this.userService.data.customersData;
    this.initializeCustomerSection(this.defaultCustomer);
    this.initializeCustomerData(); 
    console.log('cardDataList :: ' , this.cardDataList);
    console.log('customersData :: ' , this.customersData);
    console.log('currentSelectedCustomer :: ' , this.currentSelectedCustomer); 
    console.log('customerDataForm :: ' , this.customerDataForm);  
  }

  initializeCustomerData() {   
    this.customerDataForm = this.formBuilder.group({
      customerName: [this.currentSelectedCustomer[0].customerName, Validators.required],
      account: [this.currentSelectedCustomer[0].acct, Validators.required],
      ssn: [this.currentSelectedCustomer[0].ssn],
      mmn: [this.currentSelectedCustomer[0].mmn],
      line1: [this.currentSelectedCustomer[0].address.line1],
      line2: [`${this.currentSelectedCustomer[0].address.state}, ${this.currentSelectedCustomer[0].address.postalCode}`],
      email: [this.currentSelectedCustomer[0].email],
      h: [this.currentSelectedCustomer[0].h],
      w: [this.currentSelectedCustomer[0].w],
      ao: [this.currentSelectedCustomer[0].ao]
    });  
    this.cardDataList = this.currentSelectedCustomer[0].cardsData;    
  }

  initializeCustomerSection(customerType:string) {
    this.currentSelectedCustomer = this.customersData.filter(customer => {
      return customer.customerType === customerType;
    })
  }
  
  onCustomerChange(customer:any) {   
    this.initializeCustomerSection(customer.customerType);
    this.initializeCustomerData();   
  }

  _showMMN() {
    this.showMMN = !this.showMMN;
    if(this.showMMN)  
      this.buttonName = "Hide";
    else
      this.buttonName = "Show";
  }

  // Syncs the Card tab's and Data shows on click
  syncCardData(index) {
    console.log("called", index);
    this.selectedCard = +index;
    console.log(this.selectedCard);
  }

  // Syncs the tab's on click
  syncTabView(index) {    
    this.selectedTab = +index;   
  }

  // toggles the visiblity of calendar
  toggleCalendar() {
    this.calendarVisibility = !this.calendarVisibility;
  }
}
