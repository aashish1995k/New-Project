﻿import { Injectable } from '@angular/core';
import { HttpRequest, HttpResponse, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, mergeMap, materialize, dematerialize } from 'rxjs/operators';

@Injectable()
export class FakeBackendInterceptor implements HttpInterceptor {

    constructor() { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        console.log('intercept');
        // array in local storage for registered users
        let users: any[] = [];
        users.push({username: 'aashish', password: 'Apps@1234'});    
        // wrap in delayed observable to simulate server api call
        return of(null).pipe(mergeMap(() => {

            // authenticate
            if (request.url.endsWith('/users/authenticate') && request.method === 'POST') {
                // find if any user matches login credentials
                let filteredUsers = users.filter(user => {               
                    return user.username === request.body.username && user.password === request.body.password;
                });

                if (filteredUsers.length) {                   
                    // if login details are valid return 200 OK with user details and fake jwt token
                    let user = filteredUsers[0];
                    let body = {};

                    return of(new HttpResponse({ status: 200, body: body }));
                } else {
                    // else return 400 bad request
                    return throwError({ error: { message: 'Username or password is incorrect' } });
                }
            }

            // get users
            if (request.url.endsWith('/data') && request.method === 'GET') {
                console.log('data');
                // check for fake auth token in header and return users if valid, this security is implemented server side in a real application
                    let body = {                    
                        token: 'fake-jwt-token',

                        header: {
                            currentDate: new Date(),
                           // logonTime: `${new Date().getHours} - ${new Date().getMinutes()} - ${new Date().getSeconds()}`,
                            cssID: 'CAQ',
                            dvop: '',
                            accounts: '',
                            amtPromised: ''
                        },

                        customersData: [
                            {
                                customerType: 'Primary Customer',
                                acct: '1234-5678-9810-1234',
                                ssn: 'XXX.XXX.6703',
                                mmn: 'XXX-XXXX-XXXX',
                                address: {
                                    line1: 'EDGEMOOR',
                                    line2: '',
                                    city: '',
                                    state: 'DE',
                                    postalCode: '19802',
                                    countryCode: ''
                                },
                                email: 'harryPotter@hogwart.com',
                                h: '(201)-645-2871',
                                w: '(201)-645-2871',
                                ao: '(201)-645-2871',
                                cardsData: [
                                    {
                                        cardNo: '1234',
                                        amtDue: 10.00,
                                        amtPstDue: 0.00,
                                        dayPstDue: 0,
                                        balance: 39.00,
                                        creditLimit: 20000.00,
                                        availCredit: 19961.00,
                                        lastPayment: 0.00,
                                        lastMonetory: 'Credit',
                                        ctdActivity: 'Active',
                                        disputes: ''
                                    },
                                    {
                                        cardNo: '5678',
                                        amtDue: 10.00,
                                        amtPstDue: 0.00,
                                        dayPstDue: 0,
                                        balance: 39.00,
                                        creditLimit: 20000.00,
                                        availCredit: 19961.00,
                                        lastPayment: 0.00,
                                        lastMonetory: 'Credit',
                                        ctdActivity: 'Active',
                                        disputes: ''
                                    },
                                    {
                                        cardNo: '9876',
                                        amtDue: 20.00,
                                        amtPstDue: 0.00,
                                        dayPstDue: 0,
                                        balance: 59.00,
                                        creditLimit: 26000.00,
                                        availCredit: 19061.00,
                                        lastPayment: 0.00,
                                        lastMonetory: 'Credit',
                                        ctdActivity: 'Active',
                                        disputes: ''
                                    }
                                ]
                            },
                            {
                                customerType: 'Secondary Customer',
                                acct: '3456-7890-1234-5678',
                                ssn: 'XXX.XXX.6903',
                                mmn: 'XXX-XXXX-XXXX',
                                address: {
                                    line1: 'EDGEMOOR',
                                    line2: '',
                                    city: '',
                                    state: 'DE',
                                    postalCode: '19802',
                                    countryCode: ''
                                },
                                email: 'chinese@gov.ch',
                                h: '(301)-645-2871',
                                w: '(301)-645-2871',
                                ao: '(301)-645-2871',
                                cardsData: [
                                    {
                                        cardNo: '1236',
                                        amtDue: 130.00,
                                        amtPstDue: 30.00,
                                        dayPstDue: 0,
                                        balance: 3933.00,
                                        creditLimit: 2330000.00,
                                        availCredit: 1339961.00,
                                        lastPayment: 0.00,
                                        lastMonetory: 'Credit',
                                        ctdActivity: 'Active',
                                        disputes: ''
                                    }                                
                                ]

                            },
                            {
                                customerType: 'Auth Customer',
                                acct: '9876-5432-1098-7654',
                                ssn: 'XXX.XXX.6704',
                                mmn: 'XXX-XXXX-XXXX',
                                address: {
                                    line1: 'EDGEMOOR',
                                    line2: '',
                                    city: '',
                                    state: 'DE',
                                    postalCode: '19802',
                                    countryCode: ''
                                },
                                email: 'tonyStark@marvels.com',
                                h: '(201)-665-2871',
                                w: '(201)-665-2871',
                                ao: '(201)-665-2871'  ,
                                cardsData: [
                                    {
                                        cardNo: '1239',
                                        amtDue: 1330.00,
                                        amtPstDue: 0.00,
                                        dayPstDue: 0,
                                        balance: 3933.00,
                                        creditLimit: 3320000.00,
                                        availCredit: 1119961.00,
                                        lastPayment: 110.00,
                                        lastMonetory: 'Credit',
                                        ctdActivity: 'Active',
                                        disputes: ''
                                    },
                                    {
                                        cardNo: '5678',
                                        amtDue: 90.00,
                                        amtPstDue: 0.00,
                                        dayPstDue: 0,
                                        balance: 439.00,
                                        creditLimit: 2000000.00,
                                        availCredit: 33333.00,
                                        lastPayment: 0.00,
                                        lastMonetory: 'Debit',
                                        ctdActivity: 'InActive',
                                        disputes: ''
                                    }
                                ]
                              
                            }
                        ]
                    };
                    console.log('before sending');
                    return of(new HttpResponse({ status: 200, body: body }));
              
            }

            // get user by id
            if (request.url.match(/\/users\/\d+$/) && request.method === 'GET') {
                // check for fake auth token in header and return user if valid, this security is implemented server side in a real application
                if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
                    // find user by id in users array
                    let urlParts = request.url.split('/');
                    let id = parseInt(urlParts[urlParts.length - 1]);
                    let matchedUsers = users.filter(user => { return user.id === id; });
                    let user = matchedUsers.length ? matchedUsers[0] : null;

                    return of(new HttpResponse({ status: 200, body: user }));
                } else {
                    // return 401 not authorised if token is null or invalid
                    return throwError({ status: 401, error: { message: 'Unauthorised' } });
                }
            }

            // register user
            if (request.url.endsWith('/users/register') && request.method === 'POST') {
                // get new user object from post body
                let newUser = request.body;

                // validation
                let duplicateUser = users.filter(user => { return user.username === newUser.username; }).length;
                if (duplicateUser) {
                    return throwError({ error: { message: 'Username "' + newUser.username + '" is already taken' } });
                }

                // save new user
                newUser.id = users.length + 1;
                users.push(newUser);
                localStorage.setItem('users', JSON.stringify(users));

                // respond 200 OK
                return of(new HttpResponse({ status: 200 }));
            }

            // delete user
            if (request.url.match(/\/users\/\d+$/) && request.method === 'DELETE') {
                // check for fake auth token in header and return user if valid, this security is implemented server side in a real application
                if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
                    // find user by id in users array
                    let urlParts = request.url.split('/');
                    let id = parseInt(urlParts[urlParts.length - 1]);
                    for (let i = 0; i < users.length; i++) {
                        let user = users[i];
                        if (user.id === id) {
                            // delete user
                            users.splice(i, 1);
                            localStorage.setItem('users', JSON.stringify(users));
                            break;
                        }
                    }

                    // respond 200 OK
                    return of(new HttpResponse({ status: 200 }));
                } else {
                    // return 401 not authorised if token is null or invalid
                    return throwError({ status: 401, error: { message: 'Unauthorised' } });
                }
            }

            // pass through any requests not handled above
            return next.handle(request);
            
        }))

        // call materialize and dematerialize to ensure delay even if an error is thrown (https://github.com/Reactive-Extensions/RxJS/issues/648)
        .pipe(materialize())
        .pipe(delay(500))
        .pipe(dematerialize());
    }
}

export let fakeBackendProvider = {
    // use fake backend in place of Http service for backend-less development
    provide: HTTP_INTERCEPTORS,
    useClass: FakeBackendInterceptor,
    multi: true
};