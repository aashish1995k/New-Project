﻿import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

// used to create fake backend
import { fakeBackendProvider } from "./_helpers";
import { AppComponent } from "./app.component";
import { routing } from "./app.routing";
import { AlertComponent } from "./_components";
import { JwtInterceptor, ErrorInterceptor } from "./_helpers";
import { HomeComponent } from "./home";
import { LoginComponent } from "./login";
import { HeaderComponent } from "./header/header.component";
import { NavSectionComponent } from "./nav-section/nav-section.component";
import { CardsComponent } from "./cards/cards.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { FooterComponent } from "./footer/footer.component";;
import { NewHomeComponent } from './new-home/new-home.component'
;
import { SideNavComponent } from './side-nav/side-nav.component'
;
import { MainSectionComponent } from './main-section/main-section.component';
import { Section1Component } from './section1/section1.component';
import { Section2Component } from "./section2/section2.component";
@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    routing,
    NgbModule
  ],
  declarations: [
    AppComponent,
    AlertComponent,
    HomeComponent,
    LoginComponent,
    HeaderComponent,
    NavSectionComponent,
    CardsComponent,
    FooterComponent,
    NewHomeComponent ,
    SideNavComponent ,
    MainSectionComponent,
    Section1Component,
    Section2Component
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

    // provider used to create fake backend
    fakeBackendProvider
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
