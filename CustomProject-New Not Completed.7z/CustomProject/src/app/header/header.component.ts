import { Component, OnInit } from '@angular/core';

import { UserService } from '@app/_services';
import { Router } from '@angular/router';

@Component({
  selector: 'layout-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  curerentDate: Date;
  logonTime: string;
  cssID: string;
  dvop: any;
  accounts: string;
  amtPromised: string;
  headerData: any = {};
  curerentDateString: string;
  constructor(private userService: UserService) { }

  ngOnInit() {
    this.headerData = this.userService.data.header;  
    this.curerentDate = new Date();
    this.logonTime = `${this.curerentDate.getHours()}:${this.curerentDate.getMinutes()}:${this.curerentDate.getSeconds()} `;   
  }

}
